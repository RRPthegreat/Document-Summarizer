import streamlit as st
from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain_core.prompts import PromptTemplate

# -------------------------------
# Setup Summarizer
# -------------------------------
summarizer_pipeline = pipeline(
    "summarization",
    model="sshleifer/distilbart-cnn-12-6",
    tokenizer="sshleifer/distilbart-cnn-12-6",
    max_length=80,
    min_length=25,
    do_sample=False
)

llm = HuggingFacePipeline(pipeline=summarizer_pipeline)

prompt = PromptTemplate.from_template(
    """
    You are a study assistant. Read the following text and generate:

    1. 📌 A concise **Summary** (2-3 sentences).
    2. ✍️ **Bullet Point Notes** (3-5 key points).
    3. ❓ **3 Practice Questions** for revision.

    Text:
    {text}

    Provide output in clear sections.
    """
)

chain = prompt | llm

# -------------------------------
# Streamlit UI
# -------------------------------
st.set_page_config(page_title="📘 Study Notes Generator", page_icon="📝", layout="centered")

st.title("📘 Personalized Study Notes Generator")
st.write("Paste your text below and get summary, bullet notes, and practice questions.")

user_text = st.text_area("✍️ Enter your text here:", height=200)

if st.button("Generate Notes"):
    if user_text.strip():
        with st.spinner("🔎 Processing..."):
            result = chain.invoke({"text": user_text})
        st.subheader("📌 Summary, Notes & Questions")
        st.write(result)
    else:
        st.warning("⚠️ Please enter some text to summarize.")
